import { Component, OnInit } from '@angular/core';
import {Movie} from '../movie';
@Component({
  selector: 'app-for',
  templateUrl: './for.component.html',
  styleUrls: ['./for.component.css']
})
export class ForComponent implements OnInit {
public movieobj:Movie=new Movie();
  public wishlist:string[]=["iPhone","laptop","phone"];
  
  constructor() { }

  ngOnInit() {
  }


}
