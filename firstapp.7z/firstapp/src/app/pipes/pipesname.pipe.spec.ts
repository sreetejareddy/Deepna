import { PipesnamePipe } from './pipesname.pipe';

describe('PipesnamePipe', () => {
  it('create an instance', () => {
    const pipe = new PipesnamePipe();
    expect(pipe).toBeTruthy();
  });
});
