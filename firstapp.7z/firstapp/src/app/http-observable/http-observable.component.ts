import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Subscription } from 'rxjs';
@Component({
  selector: 'app-http-observable',
  templateUrl: './http-observable.component.html',
  styleUrls: ['./http-observable.component.css']
})
export class HttpObservableComponent implements OnInit {

  constructor(private http:HttpClient) { }

  ngOnInit() {
  }
  ngOnDestroy(){
    this.subscribedData.unsubscribe();
  }
  public subscribedData;
  getCall(){
    this.subscribedData=this.http.get("http://jsonplaceholder.typicode.com/users");
    console.log(typeof(this.subscribedData));
    this.subscribedData.subscribe(
      (data)=>{
      console.log(data);
      });
}
}
