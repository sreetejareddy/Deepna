export class Maths {

    Add(p1:number,p2:number){
        return p1+p2;
    }

    Multiply(p1:number,p2:number){
        return p1*p2;
    }Divide(p1:number,p2:number){
        return p1/p2;
    }
}
