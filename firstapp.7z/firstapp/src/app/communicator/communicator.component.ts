import { Component, OnInit } from '@angular/core';
import {FacebookService} from '../facebook.service';
import { TwitterService } from '../twitter.service';
@Component({
  selector: 'app-communicator',
  templateUrl: './communicator.component.html',
  styleUrls: ['./communicator.component.css']
})
export class CommunicatorComponent implements OnInit {

  constructor(public pFbService:FacebookService, public pTwitterService: TwitterService) { }
userPosts=[];
  ngOnInit() {
  }

  getfbposts(user:string){
    this.userPosts= this.pFbService.getallposts(user);
  }

}
