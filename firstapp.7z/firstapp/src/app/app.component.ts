import { Component } from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'bank';
  constructor(private router:Router){}
  
  onBtnClick(){
    this.router.navigate([{outlets:{footerOutlet:['about',1001,'Rashmi']}}])
  }
   public dis:string="hi";
   check = function(p,p1) {
    if (p.value ==p1.value) {
      document.getElementById('message').style.color = 'green';
      document.getElementById('message').innerHTML = 'Matching';
    } else {
      this.dis="not matching";
      document.getElementById('message').style.color = 'red';
      document.getElementById('message').innerHTML = 'Not Matching';
    }
    
  }
}
