import { NgModule, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes} from '@angular/router';
import { AboutComponent} from './about/about.component';
import { ServicesComponent} from './services/services.component';
import { ProductsComponent} from './products/products.component';
import { ErrorComponent} from './error/error.component';

export const router:Routes = [
  {path:'',redirectTo:"products",pathMatch:"full"},
  {path:'products',component:ProductsComponent},
  {path:'about/:id/:value',component:AboutComponent},
  {path:'services',component:ServicesComponent,outlet:"footerOutlet"},
  {path:'**', component:ErrorComponent}
]



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forRoot(router)
  ],
  exports:[RouterModule]
})
export class RoutingModule { }
