import { Component, OnInit, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-speak',
  templateUrl: './speak.component.html',
  styleUrls: ['./speak.component.css']
})
export class SpeakComponent implements OnInit {
@Input() public words:string; //[]
@Output() speak=new EventEmitter(); //()

@Input() @Output() sampleNgModel:string;
  constructor() { }

  ngOnInit() {
  }

}
