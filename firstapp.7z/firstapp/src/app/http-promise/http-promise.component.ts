import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
@Component({
  selector: 'app-http-promise',
  templateUrl: './http-promise.component.html',
  styleUrls: ['./http-promise.component.css']
})
export class HttpPromiseComponent {

  constructor(public http:HttpClient) {} 
  public prop:any=[];
  getCall(){
    this.http.get("http://jsonplaceholder.typicode.com/comments")
    .toPromise()
    .then(
      (data)=>{this.prop=data;},
      (error)=>{console.log(error);}
    )
    .catch((err)=>{
      console.log("In catch block");
      console.error(err)
    })
    .finally(()=>{console.log("In finally block");})
  }



}
