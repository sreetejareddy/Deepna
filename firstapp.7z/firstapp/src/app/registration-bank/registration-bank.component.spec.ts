import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationBankComponent } from './registration-bank.component';

describe('RegistrationBankComponent', () => {
  let component: RegistrationBankComponent;
  let fixture: ComponentFixture<RegistrationBankComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegistrationBankComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrationBankComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
