import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registration-bank',
  templateUrl: './registration-bank.component.html',
  styleUrls: ['./registration-bank.component.css']
})
export class RegistrationBankComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
