import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { FirstComponent } from './first/first.component';
import { LoginComponent } from './login/login.component';
import { IfComponent } from './if/if.component';
import { ForComponent } from './for/for.component';
import { PipesnamePipe } from './pipes/pipesname.pipe';
import { SpeakComponent } from './speak/speak.component';
import { LoginBankComponent } from './login-bank/login-bank.component';
import { RegistrationBankComponent } from './registration-bank/registration-bank.component';
import { ListenComponent } from './listen/listen.component';
import { AComponent } from './a/a.component';
import { BComponent } from './b/b.component';
import { CommunicatorComponent } from './communicator/communicator.component';
import { HttpPromiseComponent } from './http-promise/http-promise.component';
import {HttpClientModule} from '@angular/common/http';
import { HttpObservableComponent } from './http-observable/http-observable.component'
import { MatDatepickerModule} from '@angular/material/datepicker';
import {MatNativeDateModule,MatIconModule,MatButtonModule,MatCheckboxModule, MatToolbarModule, MatCardModule,MatFormFieldModule,MatInputModule,MatRadioModule,MatListModule,} from  '@angular/material';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RoutingModule } from './routing.module';
import { ProductsComponent } from './products/products.component';
import { ServicesComponent } from './services/services.component';
import { AboutComponent } from './about/about.component';
import { ErrorComponent } from './error/error.component';

@NgModule({
  declarations: [
    AppComponent,
    FirstComponent,
    LoginComponent,
    IfComponent,
    ForComponent,
    PipesnamePipe,
    SpeakComponent,
    LoginBankComponent,
    RegistrationBankComponent,
    ListenComponent,
    AComponent,
    BComponent,
    CommunicatorComponent,
    HttpPromiseComponent,
    HttpObservableComponent,
    ProductsComponent,
    ServicesComponent,
    AboutComponent,
    ErrorComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    MatNativeDateModule,
    MatDatepickerModule,
    MatIconModule,
    MatButtonModule,
    MatCheckboxModule,
     MatToolbarModule,
     FormsModule, 
     BrowserAnimationsModule,
      MatCardModule,
      MatFormFieldModule,
      MatInputModule,
      MatListModule,
      MatRadioModule,
       RoutingModule,
  ],
  exports: [MatNativeDateModule,FormsModule,
    MatDatepickerModule,
    MatIconModule,
    MatButtonModule,
    MatCheckboxModule,
     MatToolbarModule, 
     MatCardModule,
     MatFormFieldModule,
     MatInputModule,
     MatListModule,
     MatRadioModule,],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
