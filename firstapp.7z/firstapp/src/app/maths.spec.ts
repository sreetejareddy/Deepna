import { Maths } from './maths';
import { equal } from 'assert';


describe('test add functionality', () => {
  
  let obj= new Maths();
  let n1=20;
  let n2=10;
  it("True equals True",()=>{
    expect(true).toBe(true);
    expect(true).toBeTruthy();
  });

  it('should create an object',()=>{
    expect(obj).toBeTruthy();
    expect(obj).toBeDefined();
  }) ;
   it("Should add 2 numbers", ()=>{
    expect(obj.Add(n1,n2)).toEqual(30);
  });
  it("Should multiply 2 numbers", ()=>{
    expect(obj.Multiply(n1,n2)).toEqual(200);

      }); it("Should divide 2 numbers", ()=>{
    expect(obj.Divide(n1,n2)).toEqual(2);
  });

  it("Should subtract 2 number if one number is negative",()=>{
    let n1=10;
    let  n2=-20;
    expect(obj.Add(n1,n2)).toEqual(-10);
  });
});