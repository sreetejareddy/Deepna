import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-first',
  templateUrl: './first.component.html',
  styleUrls: ['./first.component.css']
})
export class FirstComponent  {


public title = 'firstapp';
public cityName:string;
public state:string;
public placesToSee:string;
public country:string;
public ratingByTripAdvisor:number;
public status:string;
constructor(){
  this.cityName="Hyderbad";
  this.state="Telangana";
  this.country="India";
  this.placesToSee="Charminar,hyatt";
  this.ratingByTripAdvisor=5;
}

OnbtnClick(pCity,pState,pCountry,pPlacestosee){
  this.cityName="bang";
  this.state=pState;
  this.country=pCountry;
  this.placesToSee=pPlacestosee;
}
}
