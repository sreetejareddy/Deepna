import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-bank',
  templateUrl: './login-bank.component.html',
  styleUrls: ['./login-bank.component.css']
})
export class LoginBankComponent implements OnInit  {

  constructor() { }

  ngOnInit() {
  }
}
