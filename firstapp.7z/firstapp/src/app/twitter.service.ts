import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TwitterService {

  constructor() { }

  getTotalTweets(user:string){
    if(user== "Deepna"){
      return 50;
    }
    return 10;
  }
}
