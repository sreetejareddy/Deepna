import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FacebookService {

  constructor() { }
getallposts(user:string){
var allposts:fbPosts[]=new fbPosts().getAllPosts();
var userposts=[];
allposts.forEach(item =>{
  if(item.username==user){
  userposts.push(item);
  }
});
return userposts;
}
getadduration(postitle:string,user:string){

}
}
 class fbPosts{
   username:string;
   posttitle:string;
   postdesc:string;
 
 private _posts:fbPosts[]=[];

getAllPosts():fbPosts[]{
  var p=new fbPosts();
  p.username="deepna";
  p.posttitle="First Post";
  p.postdesc="deepnas's first post";
  
  var p1=new fbPosts();
  p1.username="deepna1";
  p1.posttitle="First Post1";
  p1.postdesc="deepnas's first post1";
  this._posts.push(p);
  this._posts.push(p1);
  return this._posts;

  }
  }
 class fbads{
   postitle:string;
   adcost:number;
   adduration:number;
 }