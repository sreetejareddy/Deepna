import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  public username:string;
  public pwd:string;
  public loginstatus:string;
  public Login(pStatus:any,pBtn:any,pImg:any){
    pStatus.style="color:yellow";
    
    if(this.username=="admin"&&this.pwd=="1234"){
      this.loginstatus="login success";
    //  var element=<HTMLInputElement> document.getElementById("btn");
     // element.disabled=true;
    
     pBtn.disabled = "disabled";
     pImg.src="/assets/images.png"
    }
    else{
      this.loginstatus="login failed";
      pBtn.disabled = "disabled";
   
    }
  }

}
