export class Movie {
    Moviename:string="Deepna";
}
