import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistationComponentComponent } from './registation-component.component';

describe('RegistationComponentComponent', () => {
  let component: RegistationComponentComponent;
  let fixture: ComponentFixture<RegistationComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegistationComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistationComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
