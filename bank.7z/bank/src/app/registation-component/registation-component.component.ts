import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registation-component',
  templateUrl: './registation-component.component.html',
  styleUrls: ['./registation-component.component.css']
})
export class RegistationComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  showMsg: boolean = false;

  onSubmit() {
      this.userService.createUser(this.addForm.value)
        .subscribe( data => {
          this.router.navigate(['list-user']);
          this.showMsg= true;
        });
    }
}
