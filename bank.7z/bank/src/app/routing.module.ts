import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RegistationComponentComponent} from './registation-component/registation-component.component';
import {LoginComponentComponent} from './login-component/login-component.component';

import { RouterModule, Routes} from '@angular/router';

export const router:Routes = [
  { path: '', redirectTo: '/', pathMatch: 'full' },
      { path: 'register', component: RegistationComponentComponent },
      { path: 'login', component: LoginComponentComponent },
     ]



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    [RouterModule.forRoot(router)]
  ],
  exports:[RouterModule]

})
export class RoutingModule { }
